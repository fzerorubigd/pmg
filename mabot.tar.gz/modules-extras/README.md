#Module Extras

This folder includes modules which you can optionally install.

Some of them are by me, modules which simply do not fit in as a sensible part of the base installation.

Others have been created by other developers, who have sent their modules to me to be placed here.
These ones have been tested by me, however they are not guaranteed as stable and should be treated with caution.

Please enjoy AwesomeBot sensibly, and don't turn any IRCops' lives into a living hell.