<?php
	define ('WELCOME_TOPIC',)
